# Clink N Co keyword map

Each page uses one primary keyword and a few close secondary keywords. These are starting keywords based on search intent, not search-volume-validated estimates.

| Page | Primary keyword | Secondary keywords |
|---|---|---|
| Homepage | keychains | keychain collection, keychain designs, accessories brand |
| Collection | keychains online | cute keychains, collectible keychains, keychain collection |
| Product page | exact product name | material, design, gift use (set per product in the CMS) |
| About | Clink N Co | Clink N Co keychains, accessories brand |
| Blog post | one topic keyword | close informational terms (set per post in the CMS) |
| Contact | Clink N Co contact | contact Clink N Co, WhatsApp enquiries |

Where to edit:
- Static pages (home, collections, about, contact, FAQ, blogs, privacy, terms): CMS > SEO - Page Titles & Descriptions (`content/seo.json`).
- Products and blog posts: their own SEO fields in the CMS.

Targets: SEO title under 60 characters, meta description under 150 characters. The build shortens anything longer and prints a warning.

Note: Google ignores the meta keywords tag. The keywords are still added to every page for other search engines and for your own record.
