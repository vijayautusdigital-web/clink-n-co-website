/**
 * Clink N Co static build.
 * Run with `npm run build` (Netlify does this automatically). Output goes to /dist.
 *
 * What it does:
 *  - copies the public site into dist/ (README, templates, netlify.toml etc. are NOT published)
 *  - generates one indexable page per published product and blog post
 *  - injects SEO tags (title, description, keywords, canonical, robots, Open Graph, Twitter, JSON-LD)
 *  - pre-renders product cards so product links are in the HTML (crawlable without JavaScript)
 *  - writes real WhatsApp / Instagram links into the HTML
 *  - writes sitemap.xml and robots.txt
 */
const fs = require("fs");
const path = require("path");

const root = __dirname;
const dist = path.join(root, "dist");

// ---------- helpers ----------
const readJSON = (p) => JSON.parse(fs.readFileSync(path.join(root, p), "utf8"));
const mkdir = (p) => fs.mkdirSync(p, { recursive: true });
const esc = (s = "") =>
  String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const replaceAll = (t, k, v) => t.split(k).join(String(v ?? ""));
const jsonLd = (obj) =>
  `<script type="application/ld+json">${JSON.stringify(obj).replace(/</g, "\\u003c")}</script>`;

function copyDir(src, dst) {
  mkdir(dst);
  for (const item of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, item.name);
    const b = path.join(dst, item.name);
    item.isDirectory() ? copyDir(a, b) : fs.copyFileSync(a, b);
  }
}

// Keep titles/descriptions inside the lengths search engines display.
const warnings = [];
function fit(text, max, label) {
  const t = String(text || "").trim();
  if (t.length <= max) return t;
  warnings.push(`${label} is ${t.length} characters (max ${max}); shortened.`);
  return t.slice(0, max - 3).replace(/\s+\S*$/, "").trim() + "...";
}

// ---------- load content ----------
const site = readJSON("content/site.json");
const productData = readJSON("content/products.json");
const blogData = readJSON("content/blogs.json");
const seoData = fs.existsSync(path.join(root, "content/seo.json")) ? readJSON("content/seo.json") : { pages: [] };

const base = (site.siteUrl || "https://clinknco.netlify.app").replace(/\/$/, "");
const brand = site.brandName || "Clink N Co";
const published = (productData.products || []).filter((p) => p.published !== false);
const blogs = (blogData.blogs || []).filter((b) => b.published !== false);
const seoByPath = Object.fromEntries((seoData.pages || []).map((p) => [p.path, p]));
const defaultOgImage = "/assets/images/evil-eye-bell-keychain.webp";

// ---------- WhatsApp / Instagram ----------
let waDigits = String(site.whatsappNumber || "").replace(/\D/g, "");
if (waDigits.length === 10) waDigits = "91" + waDigits; // assume India if no country code
const waLink = (message) => `https://wa.me/${waDigits}?text=${encodeURIComponent(message).replace(/'/g, "%27")}`;
const DEFAULT_WA_MESSAGE = "Hi Clink N Co! I'd like to enquire about your keychains.";
const instagramUrl = site.instagramUrl || "https://www.instagram.com/clink.n.co/";

function wireLinks(html, productWaMessage) {
  const attrs = (href) => `href="${esc(href)}" target="_blank" rel="noopener"`;
  return html
    .replace(/data-wa(\s+)href=(["'])#\2/g, () => `data-wa ${attrs(waLink(DEFAULT_WA_MESSAGE))}`)
    .replace(/data-product-wa(\s+)href=(["'])#\2/g, () =>
      `data-product-wa ${attrs(waLink(productWaMessage || DEFAULT_WA_MESSAGE))}`)
    .replace(/data-instagram(\s+)href=(["'])#\2/g, () => `data-instagram ${attrs(instagramUrl)}`);
}

// ---------- product cards (same markup as assets/js/app.js) ----------
function productCard(p) {
  return `<article class="product-card"><a href="/products/${esc(p.slug)}/" aria-label="View ${esc(p.name)}"><div class="product-image"><img src="${esc(p.image)}" alt="${esc(p.alt || p.name)}" loading="lazy" width="600" height="750"></div><h3>${esc(p.name)}</h3></a><p>${esc(p.shortDescription || p.category || "Keychain")}</p><a class="card-link" href="/products/${esc(p.slug)}/">View product ↗</a></article>`;
}
function prerenderGrid(html, id, products) {
  const re = new RegExp(`(<div\\b[^>]*\\bid="${id}"[^>]*>)[\\s\\S]*?(</div>)`);
  const cards = products.map(productCard).join("");
  return cards ? html.replace(re, (m, open, close) => open + cards + close) : html;
}

// ---------- SEO block ----------
function stripSeoTags(html) {
  return html
    .replace(/<title>[\s\S]*?<\/title>/i, "")
    .replace(/<meta\s+name=["'](description|keywords|robots)["'][^>]*>/gi, "")
    .replace(/<link\s+rel=["']canonical["'][^>]*>/gi, "");
}

function applySeo(html, o) {
  const title = fit(o.title, 60, `Title of ${o.path}`);
  const description = fit(o.description, 150, `Meta description of ${o.path}`);
  const url = base + o.path;
  const image = base + (o.image || defaultOgImage);
  const keywords = [...new Set((o.keywords || []).map((k) => String(k).trim()).filter(Boolean))].join(", ");
  const robots = o.noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large";
  const lines = [
    `<title>${esc(title)}</title>`,
    `<meta name="description" content="${esc(description)}">`,
    keywords ? `<meta name="keywords" content="${esc(keywords)}">` : "",
    `<meta name="robots" content="${robots}">`,
    `<link rel="canonical" href="${esc(url)}">`,
    `<link rel="icon" type="image/webp" href="/assets/images/brand-logo.webp">`,
    `<meta property="og:site_name" content="${esc(brand)}">`,
    `<meta property="og:locale" content="en_IN">`,
    `<meta property="og:type" content="${o.ogType || "website"}">`,
    `<meta property="og:title" content="${esc(title)}">`,
    `<meta property="og:description" content="${esc(description)}">`,
    `<meta property="og:url" content="${esc(url)}">`,
    `<meta property="og:image" content="${esc(image)}">`,
    o.imageAlt ? `<meta property="og:image:alt" content="${esc(o.imageAlt)}">` : "",
    `<meta name="twitter:card" content="summary_large_image">`,
    `<meta name="twitter:title" content="${esc(title)}">`,
    `<meta name="twitter:description" content="${esc(description)}">`,
    `<meta name="twitter:image" content="${esc(image)}">`,
    ...(o.jsonld || []).map(jsonLd),
  ].filter(Boolean);
  const block = lines.join("");
  let out = stripSeoTags(html);
  if (/<meta\s+name=["']viewport["'][^>]*>/i.test(out)) {
    out = out.replace(/(<meta\s+name=["']viewport["'][^>]*>)/i, (m) => m + block);
  } else {
    out = out.replace(/<\/head>/i, () => block + "</head>");
  }
  return out;
}

const breadcrumb = (items) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: items.map((it, i) => ({
    "@type": "ListItem",
    position: i + 1,
    name: it.name,
    item: base + it.path,
  })),
});

// Pull the existing <title>/<meta description> as a fallback for pages missing from seo.json.
function existingSeo(html) {
  const t = html.match(/<title>([\s\S]*?)<\/title>/i);
  const d = html.match(/<meta\s+name=["']description["']\s+content=["']([^"']*)["']/i);
  return { title: t ? t[1].trim() : brand, description: d ? d[1].trim() : "" };
}

// ---------- 1. copy the public site into dist ----------
if (fs.existsSync(dist)) fs.rmSync(dist, { recursive: true, force: true });
mkdir(dist);
const SKIP_DIRS = new Set(["dist", "node_modules", ".git", "templates"]);
const SKIP_FILES = new Set([
  "build.js", "package.json", "package-lock.json", "README.md", "SEO-KEYWORD-MAP.md", "netlify.toml", ".gitignore",
]);
for (const item of fs.readdirSync(root, { withFileTypes: true })) {
  const src = path.join(root, item.name);
  const dst = path.join(dist, item.name);
  if (item.isDirectory()) {
    if (!SKIP_DIRS.has(item.name)) copyDir(src, dst);
  } else if (!SKIP_FILES.has(item.name)) {
    fs.copyFileSync(src, dst);
  }
}

// ---------- 2. static pages (home, collections, about, contact, faq, blogs, privacy, terms, ...) ----------
const NON_PAGE_DIRS = new Set(["admin", "assets", "content", "products"]);
const staticPaths = ["/"];
for (const d of fs.readdirSync(root, { withFileTypes: true })) {
  if (!d.isDirectory() || SKIP_DIRS.has(d.name) || NON_PAGE_DIRS.has(d.name)) continue;
  if (fs.existsSync(path.join(root, d.name, "index.html"))) staticPaths.push(`/${d.name}/`);
}
const featuredProducts = published.filter((p) => p.featured).slice(0, 4);
const noindexPaths = new Set();

for (const p of staticPaths) {
  const file = path.join(dist, p === "/" ? "index.html" : `${p.slice(1)}index.html`);
  let html = fs.readFileSync(file, "utf8");
  const cfg = seoByPath[p];
  if (!cfg) warnings.push(`No entry for ${p} in content/seo.json; using the page's existing title/description.`);
  const meta = cfg || existingSeo(html);
  if (cfg?.noindex) noindexPaths.add(p);

  html = prerenderGrid(html, "featured-products", featuredProducts);
  html = prerenderGrid(html, "catalog-products", published);

  const jsonldBlocks = [];
  if (p === "/") {
    jsonldBlocks.push({
      "@context": "https://schema.org",
      "@type": "Organization",
      name: brand,
      url: base + "/",
      logo: base + "/assets/images/brand-logo.webp",
      sameAs: [instagramUrl],
      contactPoint: [{
        "@type": "ContactPoint",
        contactType: "customer service",
        telephone: String(site.whatsappNumber || ""),
        availableLanguage: ["English", "Hindi"],
      }],
    });
    jsonldBlocks.push({ "@context": "https://schema.org", "@type": "WebSite", name: brand, url: base + "/" });
  } else {
    jsonldBlocks.push(breadcrumb([{ name: "Home", path: "/" }, { name: meta.title.split("|")[0].trim(), path: p }]));
  }

  html = applySeo(html, {
    path: p,
    title: meta.title,
    description: meta.description,
    keywords: meta.keywords,
    noindex: cfg?.noindex,
    jsonld: jsonldBlocks,
  });
  fs.writeFileSync(file, wireLinks(html));
}

// ---------- 3. individual product pages ----------
const template = fs.readFileSync(path.join(root, "templates/product.html"), "utf8");
for (const p of published) {
  const pagePath = `/products/${p.slug}/`;
  const title = p.seoTitle || `${p.name} | ${brand}`;
  const description =
    p.metaDescription || `Explore ${p.name} from ${brand}. View product details and enquire on WhatsApp.`;
  const schema = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    description: p.description,
    image: [base + p.image],
    sku: p.slug,
    url: base + pagePath,
    brand: { "@type": "Brand", name: brand },
    category: p.category,
  };
  const vals = {
    "{{PRODUCT_SCHEMA}}": JSON.stringify(schema).replace(/</g, "\\u003c"),
    "{{SLUG}}": esc(p.slug),
    "{{PRODUCT_NAME}}": esc(p.name),
    "{{CATEGORY}}": esc(p.category),
    "{{IMAGE}}": esc(p.image),
    "{{ALT}}": esc(p.alt || p.name),
    "{{SHORT_DESCRIPTION}}": esc(p.shortDescription),
    "{{DESCRIPTION}}": esc(p.description),
    "{{MATERIAL}}": esc(p.material || "Please enquire"),
    "{{DESIGN}}": esc(p.design || "Please enquire"),
    "{{GIFT_USE}}": esc(p.giftUse || "Gift or collectible"),
    // these three are replaced again by applySeo(); filled so the template never leaks raw tokens
    "{{SEO_TITLE}}": esc(title),
    "{{META_DESCRIPTION}}": esc(description),
    "{{CANONICAL}}": esc(base + pagePath),
  };
  let html = template;
  for (const [k, v] of Object.entries(vals)) html = replaceAll(html, k, v);
  html = prerenderGrid(html, "featured-products", published.filter((x) => x.slug !== p.slug).slice(0, 4));
  html = applySeo(html, {
    path: pagePath,
    title,
    description,
    keywords: [p.primaryKeyword, ...(p.secondaryKeywords || []), brand],
    image: p.image,
    imageAlt: p.alt || p.name,
    jsonld: [
      breadcrumb([
        { name: "Home", path: "/" },
        { name: "Keychain collection", path: "/collections/" },
        { name: p.name, path: pagePath },
      ]),
    ],
  });
  const waMessage = `Hi Clink N Co! I'm interested in the ${p.name} (${base + pagePath}). Please share availability and delivery details.`;
  const out = path.join(dist, "products", p.slug, "index.html");
  mkdir(path.dirname(out));
  fs.writeFileSync(out, wireLinks(html, waMessage));
}

// ---------- 4. blog pages ----------
function blogPage(b) {
  const body = (b.body || "")
    .split(/\n{2,}/).map((x) => x.trim()).filter(Boolean)
    .map((x) => (x.startsWith("#") ? `<h2>${esc(x.replace(/^#+\s*/, ""))}</h2>` : `<p>${esc(x).replace(/\n/g, " ")}</p>`))
    .join("\n");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/assets/css/styles.css"><script defer src="/assets/js/app.js"></script></head><body><div class="announcement">Clink N Co · Accessories · WhatsApp to enquire</div><header class="site-header"><a class="brand" href="/"><img src="/assets/images/brand-logo.webp" alt="Clink N Co"></a><button class="menu-toggle" aria-label="Open navigation" aria-expanded="false">☰</button><nav class="main-nav"><a href="/">Home</a><a href="/collections/">Collections</a><a href="/blogs/">Blogs</a><a href="/about/">About</a><a href="/contact/">Contact</a></nav><a class="header-cta" data-wa href="#">WhatsApp</a></header><main><article class="content-page"><p class="eyebrow">${esc(b.primaryKeyword || "CLINK N CO BLOG")}</p><h1>${esc(b.title)}</h1><p>${esc(b.excerpt || "")}</p>${b.featuredImage ? `<img src="${esc(b.featuredImage)}" alt="${esc(b.imageAlt || b.title)}" loading="lazy">` : ""}${body}<p><a class="button button-dark" data-wa href="#">Ask us on WhatsApp ↗</a></p></article></main><footer class="site-footer"><div class="footer-brand"><img src="/assets/images/brand-logo.webp" alt="Clink N Co"><p>Accessories for the things you love.</p></div><div><h3>Explore</h3><a href="/">Home</a><a href="/collections/">Collections</a><a href="/blogs/">Blogs</a><a href="/contact/">Contact</a></div><div><h3>Information</h3><a href="/faq/">FAQ</a><a href="/privacy/">Privacy Policy</a><a href="/terms/">Terms of Use</a></div><div><h3>Connect</h3><a data-wa href="#">WhatsApp enquiries</a><a data-instagram href="#">Instagram</a></div><div class="copyright">© <span data-year></span> Clink N Co.</div></footer></body></html>`;
}
for (const b of blogs) {
  const slug = b.slug || "article";
  const pagePath = `/blogs/${slug}/`;
  const html = applySeo(blogPage(b), {
    path: pagePath,
    title: b.seoTitle || b.title,
    description: b.metaDescription || b.excerpt || "",
    keywords: [b.primaryKeyword, ...(b.secondaryKeywords || []), brand],
    image: b.featuredImage || undefined,
    imageAlt: b.imageAlt || b.title,
    ogType: "article",
    jsonld: [
      {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        headline: b.title,
        description: b.metaDescription || b.excerpt || "",
        datePublished: b.date || undefined,
        image: b.featuredImage ? base + b.featuredImage : undefined,
        author: { "@type": "Organization", name: brand },
        publisher: { "@type": "Organization", name: brand },
        mainEntityOfPage: base + pagePath,
      },
      breadcrumb([{ name: "Home", path: "/" }, { name: "Blogs", path: "/blogs/" }, { name: b.title, path: pagePath }]),
    ],
  });
  const out = path.join(dist, "blogs", slug, "index.html");
  mkdir(path.dirname(out));
  fs.writeFileSync(out, wireLinks(html));
}

// ---------- 5. sitemap.xml ----------
const today = new Date().toISOString().slice(0, 10);
const entries = [
  ...staticPaths.filter((p) => !noindexPaths.has(p)).map((p) => ({ loc: p })),
  ...published.map((p) => ({ loc: `/products/${p.slug}/`, image: p.image, imageTitle: p.name })),
  ...blogs.map((b) => ({ loc: `/blogs/${b.slug}/`, lastmod: b.date ? String(b.date).slice(0, 10) : today })),
];
const sitemap =
  `<?xml version="1.0" encoding="UTF-8"?>\n` +
  `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n` +
  entries
    .map(
      (e) =>
        `  <url><loc>${esc(base + e.loc)}</loc><lastmod>${e.lastmod || today}</lastmod>` +
        (e.image ? `<image:image><image:loc>${esc(base + e.image)}</image:loc><image:title>${esc(e.imageTitle)}</image:title></image:image>` : "") +
        `</url>`
    )
    .join("\n") +
  `\n</urlset>\n`;
fs.writeFileSync(path.join(dist, "sitemap.xml"), sitemap);

// ---------- 6. robots.txt ----------
// A bot with its own group ignores the "*" group, so every group repeats the Disallow line.
const SEARCH_BOTS = ["Googlebot", "Googlebot-Image", "Bingbot", "DuckDuckBot", "Applebot", "YandexBot"];
// Bots that fetch pages so people can find/cite you in AI answers, or when someone asks an assistant to open your page.
const AI_SEARCH_BOTS = ["OAI-SearchBot", "ChatGPT-User", "Claude-SearchBot", "Claude-User", "PerplexityBot", "Perplexity-User"];
// Bots whose main purpose is collecting content to train AI models. Controlled by "allowAiTrainingCrawlers" in content/site.json.
const AI_TRAINING_BOTS = ["GPTBot", "ClaudeBot", "Google-Extended", "Applebot-Extended", "CCBot"];
const group = (agents, rules) => agents.map((a) => `User-agent: ${a}`).join("\n") + `\n${rules}\n`;
const allowRules = "Allow: /\nDisallow: /admin/";
const robots = [
  `# robots.txt for ${brand} (${base})`,
  `# This is a request to well-behaved crawlers, not security. The CMS is protected by its own login.`,
  ``,
  `# Search engines`,
  group(SEARCH_BOTS, allowRules),
  `# AI search and assistant crawlers (help ${brand} show up and be cited in AI answers)`,
  group(AI_SEARCH_BOTS, allowRules),
  site.allowAiTrainingCrawlers
    ? `# AI model-training crawlers (allowed)\n${group(AI_TRAINING_BOTS, allowRules)}`
    : `# AI model-training crawlers (not allowed; set "allowAiTrainingCrawlers" to true in content/site.json to allow)\n${group(AI_TRAINING_BOTS, "Disallow: /")}`,
  `# Everyone else`,
  `User-agent: *\n${allowRules}\n`,
  `Sitemap: ${base}/sitemap.xml`,
  ``,
].join("\n");
fs.writeFileSync(path.join(dist, "robots.txt"), robots);

// ---------- done ----------
for (const w of warnings) console.warn("WARNING:", w);
console.log(
  `Built ${brand}: ${staticPaths.length} pages, ${published.length} product pages, ${blogs.length} blog pages, sitemap.xml and robots.txt.`
);
